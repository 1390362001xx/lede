[中文](README.md) ←

# OpenWrt CI - compile openwrt by GitHub Actions. 

## [![Build](https://img.shields.io/github/workflow/status/KFERMercer/OpenWrt/OpenWrt-CI/master?)](https://github.com/KFERMercer/OpenWrt/actions?query=workflow%3AOpenWrt-CI) [![Release](https://img.shields.io/github/release/KFERMercer/OpenWrt-CI?color=blue)](https://github.com/KFERMercer/OpenWrt-CI/releases)

### Please read source code before use.

## Basic Usage：

Copy `openwrt-ci.yml` to your forked repository `/.github/workflows/openwrt-ci.yml`

### (!! Dangerous !!)self merging upstream branch: 

Also copy `merge-upstream.yml` to `/.github/workflows/merge-upstream.yml`
